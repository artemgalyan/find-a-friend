CREATE TABLE animal_type(
    animal_type_id INT PRIMARY KEY AUTO INCREMENT,
    name VARCHAR(max) NOT NULL
);