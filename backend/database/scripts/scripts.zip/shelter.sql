CREATE TABLE shelter(
    shelter_id INT PRIMARY KEY AUTO INCREMENT,
    place_id INT NOT NULL
)