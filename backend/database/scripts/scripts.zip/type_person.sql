create table type_person (
	type_person_id INT NOT NULL PRIMARY KEY,
	name VARCHAR(50) NOT NULL
);
insert into type_person (type_person_id, name) values (1, 'ситтер');
insert into type_person (type_person_id, name) values (2, 'волонтёр');
