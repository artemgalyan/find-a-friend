create table type_animal (
	type_animal_id INT NOT NULL PRIMARY KEY,
	name VARCHAR(50) NOT NULL
);
insert into type_animal (type_animal_id, name) values (1, 'кот');
insert into type_animal (type_animal_id, name) values (2, 'собака');
insert into type_animal (type_animal_id, name) values (3, 'лошадь');
